@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4">


            </div>
        </div>
    </div>
@endsection
