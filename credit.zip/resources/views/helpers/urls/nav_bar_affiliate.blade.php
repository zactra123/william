<li class="nav-item"><a title="Home" href="{{url('/')}}">Home</a></li>
<li class="nav-item"><a href="{{ route('affiliate.create.client')}}" >ADD CLIENT</a></li>
