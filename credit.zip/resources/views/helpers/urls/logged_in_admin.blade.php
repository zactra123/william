<li class="menu-item"><a href="{{ route('admin.message.index')}}" >MESSAGES</a></li>
{{--        <li class="menu-item"><a href="{{ route('admin.client.list')}}" >User List</a></li>--}}
<li class="menu-item"><a href="{{ route('adminRec.client.list')}}" >USER LIST</a></li>
<li class="menu-item"><a href="{{ route('adminRec.toDo.list')}}" >TO DO List</a></li>
<li><a href="{{ route('admins.bank.show')}}">FURNISHERs/CRAs</a></li>


