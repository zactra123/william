<li class="nav-item"><a href="{{ url('receptionist/message') }}" class="branding pull-left">HOME</a></li>
<li class="menu-item nav-item"><a href="{{ route('adminRec.changePassword')}}" >CHANGE PASSWORD</a></li>


<li class="menu-item nav-item">
    <a href="{{ route('receptionist.liveChat.index')}}"> <span>CHAT</span>
        <span class="pl-1">
            <i class="fa fa-envelope" aria-hidden="true"></i>
        </span>
        @if(!empty($all_unreads))
            <span id="allMessageCount" class="pl-1"> {{array_sum(Auth::user()->unreads(["type" => "to"]))}}</span>
        @endif
    </a>

</li>
<li class="menu-item nav-item"><a href="{{ route('adminRec.client.list')}}" >CLIENT LIST</a></li>
<li class="menu-item nav-item"><a href="{{ route('adminRec.affiliate.list')}}" >AFFILIATE LIST</a></li>
<li class="menu-item nav-item"><a href="{{ route('adminRec.toDo.list')}}" >TO DO LISTt</a></li>
<li class="nav-item"><a href="{{ route('admins.bank.show')}}">FURNISHERs/CRAs</a></li>

