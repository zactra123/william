<li class="menu-item"><a href="{{ route('owner.reports.index')}}">REPORTS</a></li>
<li><a href="{{ route('owner.admin.index')}}">ADMINS</a></li>
<li><a href="{{ route('owner.receptionist.index')}}">RECEPTIONIST</a></li>
<li><a href="{{ route('owner.client.index')}}" >CLIENTS</a></li>
<li><a href="{{ route('owner.affiliate.index')}}" >AFFILIATES</a></li>
<li><a href="{{ route('admins.bank.show')}}">FURNISHERs/CRAs</a></li>
<li><a href="{{ route('admins.bank.types')}}">FURNISHERs/CRAs TYPES</a></li>
<li> <a href="{{ url('owner/message')}}">MESSAGES</a> </li>
<li><a href="{{ url('owner/message')}}">MESSAGES</a></li>
<li><a href="{{ route('owner.affiliate.pricing')}}">PRICING</a></li>
<li><a href="{{route('owner.credit.education.index')}}">EDUCATIONS</a></li>
<li><a href="{{route('owner.slogans.index')}}">VIEW SLOGANS</a></li>
<li><a href="{{route('owner.slogans.create')}}">ADD SLOGANS</a></li>
<li><a href="{{route('owner.faqs.index')}}">VIEW FAQs</a></li>
<li><a href="{{route('owner.faqs.create')}}">ADD FAQs</a></li>
<li><a href="{{route('owner.faqs.question')}}">QUESTION</a></li>
