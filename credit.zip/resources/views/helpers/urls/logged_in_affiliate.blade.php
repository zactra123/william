<li><a href="{{url('/affiliate')}}">HOME</a></li>
<li class="menu-item"><a href="{{ route('affiliate.create.client')}}" >ADD CLIENT</a></li>

