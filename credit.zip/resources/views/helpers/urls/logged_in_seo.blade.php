<li class="menu-item"><a href="{{ route('blog.index')}}" >BLOG</a></li>



