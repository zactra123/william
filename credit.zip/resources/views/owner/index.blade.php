@extends('layouts.admin')

@section('content')


    <section class="header-title section-padding">
        <div class="container text-center">

        </div>
    </section>

    <section class="ms-working working-section section-padding">
        <div class="container">
            <div class="section-title text-center">


            </div> <!-- section-wrapper -->
        </div>
    </section>
@endsection
