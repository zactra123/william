/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */


require('./clients/add_clients.js');
require('./clients/verify.js');
require('./clients/important_info.js');
require('./clients/index.js');
require('./clients/verify.js');

